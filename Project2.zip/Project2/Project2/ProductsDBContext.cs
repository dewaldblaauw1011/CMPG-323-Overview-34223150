﻿namespace Project2
{
    internal class ProductsDBContext
    {
    }
}